import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(page_title="Titanic Interactive Dashboard", page_icon="🚢", layout="wide")

st.markdown("""
<style>
    .main {background-color: #f7f9fc;}
    [data-testid="stMetric"] {
        background: white; padding: 16px; border-radius: 12px;
        border: 1px solid #e8edf5;
    }
    h1, h2, h3 {color: #17324d;}
</style>
""", unsafe_allow_html=True)

st.title("🚢 Titanic Passenger Insights")
st.caption("Interactive exploratory data analysis of the Titanic passenger dataset")

@st.cache_data
def load_data(uploaded_file=None):
    if uploaded_file is not None:
        data = pd.read_csv(uploaded_file)
    else:
        data_path = Path(__file__).with_name("titanic_dataset.csv")
        if not data_path.exists():
            return None
        data = pd.read_csv(data_path)
    return data

with st.sidebar:
    st.header("Data & Filters")
    uploaded = st.file_uploader("Upload Titanic CSV (optional)", type=["csv"])
    data = load_data(uploaded)
    if data is None:
        st.info("Upload titanic_dataset.csv to begin.")
        st.stop()

    required = {"Survived", "Pclass", "Sex", "Age", "Fare", "Embarked"}
    missing_cols = required - set(data.columns)
    if missing_cols:
        st.error("Required columns missing: " + ", ".join(sorted(missing_cols)))
        st.stop()

    st.markdown("---")
    st.subheader("Filter passengers")
    sex_options = sorted(data["Sex"].dropna().astype(str).unique().tolist())
    selected_sex = st.multiselect("Sex", sex_options, default=sex_options)

    class_options = sorted(data["Pclass"].dropna().astype(str).unique().tolist())
    selected_class = st.multiselect("Passenger class", class_options, default=class_options)

    embarked_options = sorted(data["Embarked"].dropna().astype(str).unique().tolist())
    selected_embarked = st.multiselect("Embarkation", embarked_options, default=embarked_options)

    survived_options = sorted(data["Survived"].dropna().astype(str).unique().tolist())
    selected_survival = st.multiselect("Survival status", survived_options, default=survived_options)

    age_values = pd.to_numeric(data["Age"], errors="coerce").dropna()
    if not age_values.empty:
        min_age, max_age = int(age_values.min()), int(age_values.max())
        age_range = st.slider("Age range", min_age, max_age, (min_age, max_age))
    else:
        age_range = None

filtered = data.copy()
filtered["Sex"] = filtered["Sex"].astype(str)
filtered["Pclass"] = filtered["Pclass"].astype(str)
filtered["Embarked"] = filtered["Embarked"].fillna("Unknown").astype(str)
filtered["Survived"] = filtered["Survived"].astype(str)
filtered = filtered[
    filtered["Sex"].isin(selected_sex)
    & filtered["Pclass"].isin(selected_class)
    & filtered["Embarked"].isin(selected_embarked + (["Unknown"] if "Unknown" in filtered["Embarked"].unique() else []))
    & filtered["Survived"].isin(selected_survival)
]
if age_range is not None:
    numeric_age = pd.to_numeric(filtered["Age"], errors="coerce")
    filtered = filtered[numeric_age.isna() | numeric_age.between(age_range[0], age_range[1])]

total = len(filtered)
survived_count = (filtered["Survived"].str.lower() == "yes").sum()
survival_rate = (survived_count / total * 100) if total else 0
avg_fare = pd.to_numeric(filtered["Fare"], errors="coerce").mean() if total else 0
avg_age = pd.to_numeric(filtered["Age"], errors="coerce").mean() if total else 0

c1, c2, c3, c4 = st.columns(4)
c1.metric("Passengers", f"{total:,}")
c2.metric("Survived", f"{survived_count:,}")
c3.metric("Survival rate", f"{survival_rate:.1f}%")
c4.metric("Average fare", f"{avg_fare:.2f}" if pd.notna(avg_fare) else "N/A")

if total == 0:
    st.warning("No passengers match the selected filters. Change the filters in the sidebar.")
    st.stop()

st.markdown("### Survival overview")
left, right = st.columns(2)

survival_counts = filtered["Survived"].value_counts().rename_axis("Status").reset_index(name="Passengers")
fig_survival = px.pie(
    survival_counts, names="Status", values="Passengers", hole=0.55,
    title="Survival distribution", color="Status",
    color_discrete_map={"yes": "#1f9d8b", "no": "#e76f51"}
)
left.plotly_chart(fig_survival, use_container_width=True)

class_survival = filtered.groupby(["Pclass", "Survived"]).size().reset_index(name="Passengers")
fig_class = px.bar(
    class_survival, x="Pclass", y="Passengers", color="Survived",
    barmode="group", title="Survival by passenger class",
    color_discrete_map={"yes": "#1f9d8b", "no": "#e76f51"},
    labels={"Pclass": "Passenger class"}
)
right.plotly_chart(fig_class, use_container_width=True)

st.markdown("### Passenger characteristics")
left, right = st.columns(2)

gender_survival = filtered.groupby(["Sex", "Survived"]).size().reset_index(name="Passengers")
fig_gender = px.bar(
    gender_survival, x="Sex", y="Passengers", color="Survived", barmode="group",
    title="Survival by sex",
    color_discrete_map={"yes": "#1f9d8b", "no": "#e76f51"}
)
left.plotly_chart(fig_gender, use_container_width=True)

age_data = filtered.copy()
age_data["Age"] = pd.to_numeric(age_data["Age"], errors="coerce")
fig_age = px.histogram(
    age_data.dropna(subset=["Age"]), x="Age", color="Survived", nbins=25,
    barmode="overlay", opacity=0.72, title="Age distribution by survival",
    color_discrete_map={"yes": "#1f9d8b", "no": "#e76f51"}
)
right.plotly_chart(fig_age, use_container_width=True)

st.markdown("### Fare and embarkation")
left, right = st.columns(2)

fare_data = filtered.copy()
fare_data["Fare"] = pd.to_numeric(fare_data["Fare"], errors="coerce")
fig_fare = px.histogram(
    fare_data.dropna(subset=["Fare"]), x="Fare", nbins=40,
    title="Passenger fare distribution", marginal="box"
)
left.plotly_chart(fig_fare, use_container_width=True)

embarked_counts = filtered["Embarked"].value_counts().rename_axis("Port").reset_index(name="Passengers")
fig_embarked = px.bar(
    embarked_counts, x="Port", y="Passengers", title="Passengers by embarkation port",
    color="Port"
)
right.plotly_chart(fig_embarked, use_container_width=True)

st.markdown("### Data quality")
quality = pd.DataFrame({
    "Column": data.columns,
    "Missing values": [int(data[col].isna().sum()) for col in data.columns],
    "Missing (%)": [round(data[col].isna().mean() * 100, 1) for col in data.columns]
}).sort_values("Missing values", ascending=False)
st.dataframe(quality, use_container_width=True, hide_index=True)

with st.expander("View filtered passenger records"):
    st.dataframe(filtered, use_container_width=True, hide_index=True)

st.caption(f"Showing {total:,} of {len(data):,} records. Filters update all charts and summary metrics.")
