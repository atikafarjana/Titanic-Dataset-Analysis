# Titanic Interactive Dashboard

An interactive Streamlit dashboard for exploratory analysis of the Titanic passenger dataset.

## Run locally

1. Install Python.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the dashboard:

   ```bash
   streamlit run app.py
   ```

The dashboard opens in your browser. The included `titanic_dataset.csv` is loaded automatically. You can also upload another compatible CSV from the sidebar.

## Features

- Passenger count, survival count, survival rate, and average fare
- Survival distribution
- Survival by passenger class and sex
- Age and fare distributions
- Embarkation-port counts
- Missing-value summary
- Interactive sidebar filters and passenger-record table

## Dataset

The dashboard bundle includes the Titanic CSV used for this project (891 rows, 12 columns).
